import tkinter as tk
from tkinter import ttk
import re
import pyperclip


def format_mac_address(mac, output_format):
    mac = mac.strip().lower()
    mac = re.sub(r'[^0-9a-f]', '', mac)

    if len(mac) != 12:
        raise ValueError("Некорректный MAC-адрес")

    if output_format == 'tplink':
        return ':'.join(mac[i:i + 2] for i in range(0, 12, 2))
    elif output_format == 'huawei':
        return '-'.join(mac[i:i + 2] for i in range(0, 12, 2))
    elif output_format == 'zte':
        return '.'.join(mac[i:i + 2] for i in range(0, 12, 2))
    elif output_format == 'no-separator':
        return mac.upper()
    elif output_format == 'snr':
        return ':'.join(mac[i:i + 2] for i in range(0, 12, 2))
    elif output_format == 'qtech':
        return '-'.join(mac[i:i + 2] for i in range(0, 12, 2))
    else:
        raise ValueError("Некорректный формат вывода")


def format_mac():
    mac_address = entry.get()

    try:
        formatted_mac = format_mac_address(mac_address, selected_format.get())
        result_label.config(text=f"Отформатированный MAC-адрес: {formatted_mac}")
        pyperclip.copy(formatted_mac)  # Копируем результат в буфер обмена
    except ValueError as e:
        result_label.config(text=str(e))


def get_mac_from_clipboard():
    clipboard_content = pyperclip.paste()
    entry.delete(0, tk.END)
    entry.insert(0, clipboard_content)


def update_clipboard():
    current_clipboard_content = pyperclip.paste()
    if current_clipboard_content != entry.get():
        entry.delete(0, tk.END)
        entry.insert(0, current_clipboard_content)
    root.after(100, update_clipboard)  # Запланировать следующую проверку через 10 секунд


def set_format(format_type):
    selected_format.set(format_type)
    format_mac()  # Форматируем MAC-адрес и обновляем буфер обмена


# Создаем главное окно
root = tk.Tk()
root.title("MAC-адрес Форматер")
root.geometry("400x400")  # Задаем размер окна
root.configure(bg='white')  # Установка светлого фона окна

# Устанавливаем стиль ttk
style = ttk.Style()
style.configure('TButton', padding=10, relief='flat', background='lightgray', foreground='black',
                font=('Bebas Neue', 14))
style.map('TButton', background=[('active', 'gray')])
style.configure('TLabel', background='white', foreground='black', font=('Bebas Neue', 14))
style.configure('TEntry', fieldbackground='white', foreground='black')

# Поле ввода MAC-адреса
entry = ttk.Entry(root, width=30, font=('Bebas Neue', 14))
entry.pack(pady=10)

# Переменная для хранения выбранного формата
selected_format = tk.StringVar(value='tplink')

# Создаем контейнер для кнопок
button_frame = ttk.Frame(root)
button_frame.pack(pady=10)

# Кнопки для выбора формата
button_tplink = ttk.Button(button_frame, text="TP-Link", command=lambda: set_format('tplink'))
button_tplink.pack(side=tk.LEFT, padx=5)

button_huawei = ttk.Button(button_frame, text="Huawei", command=lambda: set_format('huawei'))
button_huawei.pack(side=tk.LEFT, padx=5)

button_zte = ttk.Button(button_frame, text="ZTE", command=lambda: set_format('zte'))
button_zte.pack(side=tk.LEFT, padx=5)

button_snr = ttk.Button(button_frame, text="SNR", command=lambda: set_format('snr'))
button_snr.pack(side=tk.LEFT, padx=5)

button_qtech = ttk.Button(button_frame, text="Q-Tech", command=lambda: set_format('qtech'))
button_qtech.pack(side=tk.LEFT, padx=5)

# Кнопка для форматирования MAC-адреса
format_button = ttk.Button(root, text="Форматировать", command=format_mac)
format_button.pack(pady=10)

# Метка для отображения результата
result_label = ttk.Label(root, text="", font=('Bebas Neue', 14), foreground='black')
result_label.pack(pady=10)

# Получаем MAC-адрес из буфера обмена и отображаем его в поле ввода
get_mac_from_clipboard()

# Запускаем обновление буфера обмена каждую секунду
update_clipboard()

# Запуск главного цикла приложения
root.mainloop()