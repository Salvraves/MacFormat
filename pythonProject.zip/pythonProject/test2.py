import pyperclip
import pystray
from PIL import Image, ImageDraw
import threading
import time


def create_image(width, height):
    # Создаем изображение для иконки трея
    image = Image.new('RGB', (width, height), (255, 255, 255))
    dc = ImageDraw.Draw(image)
    dc.rectangle(
        (0, 0, width, height),
        fill=(0, 128, 255)
    )
    return image


def format_mac_address(mac):
    mac = mac.strip().upper()
    if len(mac) != 17 or mac.count(':') != 5:
        raise ValueError("Неверный формат MAC-адреса")
    return mac


def format_mac(mac):
    try:
        original_mac = format_mac_address(mac)
        return {
            "Huawei": f"{original_mac[0:2]}:{original_mac[3:5]}:{original_mac[6:8]}:{original_mac[9:11]}:{original_mac[12:14]}:{original_mac[15:17]}",
            "TP-Link": f"{original_mac[0:2]}-{original_mac[3:5]}-{original_mac[6:8]}-{original_mac[9:11]}-{original_mac[12:14]}-{original_mac[15:17]}",
            "D-Link": f"{original_mac[0:2]}.{original_mac[3:5]}.{original_mac[6:8]}.{original_mac[9:11]}.{original_mac[12:14]}.{original_mac[15:17]}",
            "SNR": f"{original_mac.replace(':', '')[:6]}-{original_mac.replace(':', '')[6:]}",
            "Q-Tech": f"{original_mac[:2]} {original_mac[3:5]} {original_mac[6:8]} {original_mac[9:11]} {original_mac[12:14]} {original_mac[15:17]}",
            "ZTE": f"{original_mac.replace(':', '')[:4]}-{original_mac.replace(':', '')[4:8]}-{original_mac.replace(':', '')[8:]}"
        }
    except ValueError as e:
        return str(e)


def on_quit(icon, item):
    icon.stop()


def show_mac_info(icon):
    while True:
        try:
            original_mac = pyperclip.paste()  # Получаем текст из буфера обмена
            formatted_macs = format_mac(original_mac)
            print(f"Исходный MAC-адрес: {original_mac}")

            # Проверяем тип возвращаемого значения
            if isinstance(formatted_macs, dict):
                for key, value in formatted_macs.items():
                    print(f"MAC-адрес {key}: {value}")
            else:
                print(f"Ошибка: {formatted_macs}")  # Выводим сообщение об ошибке

        except Exception as e:
            print(f"Произошла ошибка: {e}")

        time.sleep(10)  # Проверяем буфер обмена каждые 10 секунд


def run_tray():
    icon = pystray.Icon("MAC Formatter", create_image(64, 64), "MAC Formatter", menu=pystray.Menu(
        pystray.MenuItem("Выход", on_quit)
    ))
    icon.run(show_mac_info)


if __name__ == "__main__":
    run_tray()