from microbit import *
import music
import neopixel

# Настройки светодиодного кольца
NUM_PIXELS = 12  # Количество светодиодов в кольце
np = neopixel.NeoPixel(pin0, NUM_PIXELS)


# Функция для отображения состояния на светодиодном кольце
def update_led_ring(direction):
    np.clear()
    if direction == "forward":
        for i in range(4):  # Подсвечиваем первые 4 светодиода
            np[i] = (0, 255, 0)  # Зеленый цвет
    elif direction == "backward":
        for i in range(4, 8):  # Подсвечиваем следующие 4
            np[i] = (255, 0, 0)  # Красный цвет
    elif direction == "left":
        for i in range(0, 6, 2):  # Подсвечиваем левую половину
            np[i] = (0, 0, 255)  # Синий цвет
    elif direction == "right":
        for i in range(1, 12, 2):  # Подсвечиваем правую половину
            np[i] = (255, 255, 0)  # Желтый цвет
    np.show()


# Проигрывание мелодии при включении
melody = [
    'C4:4', 'E4:4', 'G4:4', 'C5:4',
    'G4:4', 'E4:4', 'C4:4', 'R:4'
]
music.play(melody)

# Анимация на дисплее
frames = [
    Image.HEART,
    Image.SMILE,
    Image.HAPPY,
    Image.SAD,
    Image.HEART_SMALL
]

# Отображение анимации
for i in range(3):  # Три цикла анимации
    for frame in frames:
        display.show(frame)
        sleep(200)

# Основной цикл
while True:
    x, y, z = accelerometer.get_values()

    # Определяем направление движения
    if x > 300:
        update_led_ring("right")
    elif x < -300:
        update_led_ring("left")
    elif y > 300:
        update_led_ring("forward")
    elif y < -300:
        update_led_ring("backward")
    else:
        np.clear()
        np.show()

    sleep(100)