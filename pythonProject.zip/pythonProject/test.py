import pyperclip
import pystray
from PIL import Image, ImageDraw
import threading
import time

def create_image(width, height):
    # Создаем изображение для иконки трея
    image = Image.new('RGB', (width, height), (255, 255, 255))
    dc = ImageDraw.Draw(image)
    dc.rectangle(
        (0, 0, width, height),
        fill=(0, 128, 255)
    )
    return image

def format_huawei(mac):
    mac = format_mac_address(mac)
    return f"{mac[0:2]}:{mac[3:5]}:{mac[6:8]}:{mac[9:11]}:{mac[12:14]}:{mac[15:17]}"

def format_tp_link(mac):
    mac = format_mac_address(mac)
    return f"{mac[0:2]}-{mac[3:5]}-{mac[6:8]}-{mac[9:11]}-{mac[12:14]}-{mac[15:17]}"

def format_d_link(mac):
    mac = format_mac_address(mac)
    return f"{mac[0:2]}.{mac[3:5]}.{mac[6:8]}.{mac[9:11]}.{mac[12:14]}.{mac[15:17]}"

def format_q_tech(mac):
    mac = format_mac_address(mac)
    return f"{mac[:2]} {mac[3:5]} {mac[6:8]} {mac[9:11]} {mac[12:14]} {mac[15:17]}"

def format_zte(mac):
    mac = format_mac_address(mac)
    return f"{mac.replace(':', '')[:4]}-{mac.replace(':', '')[4:8]}-{mac.replace(':', '')[8:]}"

def format_mac_address(mac):
    # Удаляем пробелы и переводим в верхний регистр
    mac = mac.strip().upper()

    # Проверяем, что MAC-адрес имеет правильный формат
    if len(mac) != 17 or mac.count(':') != 5:
        raise ValueError("Неверный формат MAC-адреса")

    return mac

# MAC-адрес из буфера обмена
try:
    original_mac = pyperclip.paste()  # Получаем текст из буфера обмена
    print(f"Исходный MAC-адрес: {original_mac}")

    # Применяем форматы
    print(f"MAC-адрес Huawei: {format_huawei(original_mac)}")
    print(f"MAC-адрес TP-Link: {format_tp_link(original_mac)}")
    print(f"MAC-адрес D-Link: {format_d_link(original_mac)}")
    print(f"MAC-адрес Q-Tech: {format_q_tech(original_mac)}")
    print(f"MAC-адрес ZTE: {format_zte(original_mac)}")

except ValueError as e:
    print(e)
except Exception as e:
    print(f"Произошла ошибка: {e}")


def show_mac_info(icon):
    while True:
        try:
            original_mac = pyperclip.paste()  # Получаем текст из буфера обмена
            formatted_macs = format_mac_address(original_mac)
            print(f"Исходный MAC-адрес: {original_mac}")
            for key, value in formatted_macs.items():
                print(f"MAC-адрес {key}: {value}")
        except Exception as e:
            print(f"Произошла ошибка: {e}")

        time.sleep(10)  # Проверяем буфер обмена каждые 10 секунд

def on_quit(icon, item):
    icon.stop()

def run_tray():
    icon = pystray.Icon("MAC Formatter", create_image(64, 64), "MAC Formatter", menu=pystray.Menu(
        pystray.MenuItem("Выход", on_quit)
    ))
    icon.run(show_mac_info)

if __name__ == "__main__":
    run_tray()

input()